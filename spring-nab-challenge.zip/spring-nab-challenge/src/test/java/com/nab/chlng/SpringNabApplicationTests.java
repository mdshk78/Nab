package com.nab.chlng;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.nab.chlng.controller.CurrencyController;
import com.nab.chlng.model.Currency;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringNabApplicationTests {

	
	@Autowired
	CurrencyController currencyController;
	
	@Test
	public void contextLoads() {
		//Assert.assertNotNull(friendController);
	}

	@Test
	public void testCreate() {
		RestTemplate restTemplate = new RestTemplate();
		String url="http://localhost:8090/currency/1";
		
		ResponseEntity<Currency> entity = restTemplate.getForEntity(url, Currency.class);

		assertNotNull(entity);
		System.out.println(entity);
	}
	
}
