package com.nab.chlng.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.nab.chlng.model.Currency;
import com.nab.chlng.service.CurrencyService;

@RestController
public class CurrencyController {

	@Autowired
	private CurrencyService currencyService;
	
	
	@GetMapping("/currency")
	Iterable<Currency> finaAll() {
		return currencyService.findAll();
	}

	@GetMapping("/currency/{id}")
	Optional<Currency> finaById(@PathVariable int id) {
		return currencyService.findById(id);
	}

}
