package com.nab.chlng.service;

import org.springframework.data.repository.CrudRepository;

import com.nab.chlng.model.Currency;

public interface CurrencyService extends CrudRepository<Currency, Integer> {

}
