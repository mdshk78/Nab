package com.nab.chlng.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
public class Quote {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@JsonIgnore
	@Column(name="id")
	private Integer quoteId;
	private String time;
	private Double price;
}
