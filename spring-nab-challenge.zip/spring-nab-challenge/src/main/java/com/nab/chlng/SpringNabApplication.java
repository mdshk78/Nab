package com.nab.chlng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringNabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringNabApplication.class, args);
	}
}
