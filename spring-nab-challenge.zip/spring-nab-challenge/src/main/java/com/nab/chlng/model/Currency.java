package com.nab.chlng.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
public class Currency {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@JsonIgnore
	private Integer id;
	private String currency;
	private LocalDate date;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="currency_id")
	private List<Quote> quotes;
}
